package ch.bedag.a6z.sipvalidator.exception.module3;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation3cFormatValidationException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -2554852466330221247L;

    public Validation3cFormatValidationException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Validation3cFormatValidationException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}
