package ch.bedag.a6z.sipvalidator.exception.module1;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation1cNamingException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -1222566139624342954L;

    public Validation1cNamingException() {
        super();
    }

    public Validation1cNamingException(String message) {
        super(message);
    }

}
