package ch.bedag.a6z.sipvalidator.exception.module2;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation2cSurplusFilesException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -5308098707547895829L;

    public Validation2cSurplusFilesException() {
        super();
    }

    public Validation2cSurplusFilesException(String message) {
        super(message);
    }

}
