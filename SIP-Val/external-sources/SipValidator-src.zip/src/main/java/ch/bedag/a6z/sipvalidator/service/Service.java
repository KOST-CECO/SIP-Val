package ch.bedag.a6z.sipvalidator.service;

import ch.bedag.a6z.sipvalidator.logging.MessageConstants;

public interface Service extends MessageConstants {

    // Marker Interface
    
}
