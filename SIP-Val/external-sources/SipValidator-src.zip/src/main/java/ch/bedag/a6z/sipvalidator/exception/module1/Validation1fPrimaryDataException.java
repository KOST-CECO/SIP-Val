package ch.bedag.a6z.sipvalidator.exception.module1;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation1fPrimaryDataException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -4703263788956302792L;

    public Validation1fPrimaryDataException() {
        super();
    }

    public Validation1fPrimaryDataException(String message) {
        super(message);
    }

}
