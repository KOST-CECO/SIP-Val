package ch.bedag.a6z.sipvalidator.enums;

/**
 * Marker - Interface f�r EnumItem Enums. 
 * 
 * 
 */

public interface BaseEnumItemEnum {
    
    Long getId();
}
