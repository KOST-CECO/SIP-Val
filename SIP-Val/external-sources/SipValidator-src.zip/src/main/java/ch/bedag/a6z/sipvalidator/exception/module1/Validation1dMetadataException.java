package ch.bedag.a6z.sipvalidator.exception.module1;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation1dMetadataException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -5732112035022102438L;

    public Validation1dMetadataException(String message) {
        super(message);
    }

}
