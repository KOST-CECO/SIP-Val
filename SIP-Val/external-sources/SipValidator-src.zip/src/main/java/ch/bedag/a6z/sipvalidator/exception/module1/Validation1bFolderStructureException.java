package ch.bedag.a6z.sipvalidator.exception.module1;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation1bFolderStructureException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -5743334009406087977L;

    public Validation1bFolderStructureException() {
        super();
    }

    public Validation1bFolderStructureException(String message) {
        super(message);
    }

}
