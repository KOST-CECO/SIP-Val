package ch.bedag.a6z.sipvalidator.exception.module1;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation1aZipException extends SipValidatorException {

    /**
     * 
     */
    private static final long serialVersionUID = -8816841335398903517L;

    public Validation1aZipException(String message) {
        super(message);
    }

}
