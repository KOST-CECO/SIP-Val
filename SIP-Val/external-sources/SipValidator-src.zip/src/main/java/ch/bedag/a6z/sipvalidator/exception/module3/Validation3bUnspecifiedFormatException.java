package ch.bedag.a6z.sipvalidator.exception.module3;

import ch.bedag.a6z.sipvalidator.exception.SipValidatorException;

public class Validation3bUnspecifiedFormatException extends SipValidatorException {

    public Validation3bUnspecifiedFormatException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Validation3bUnspecifiedFormatException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    /**
     * 
     */
    private static final long serialVersionUID = 2762314526237098688L;

}
